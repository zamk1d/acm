import uuid
from datetime import datetime, timedelta

from sqlalchemy import DateTime, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from acm.db.base import Base, TimestampMixin


class TikTokAccount(Base, TimestampMixin):
    __tablename__ = "tiktok_accounts"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)

    # identity (open_id is unique per user per app)
    open_id: Mapped[str] = mapped_column(String(128), unique=True)
    union_id: Mapped[str | None] = mapped_column(String(128))

    # profile snapshot
    display_name: Mapped[str | None] = mapped_column(String(255))
    avatar_url: Mapped[str | None] = mapped_column(Text)

    # tokens
    # NOTE: stored as plain text. Encrypt at rest (e.g. Fernet/KMS) before going to production.
    access_token: Mapped[str] = mapped_column(Text)
    refresh_token: Mapped[str] = mapped_column(Text)
    scopes: Mapped[str] = mapped_column(Text, default="")
    access_token_expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    refresh_token_expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    def is_access_token_expired(self, now: datetime, leeway: timedelta = timedelta(0)) -> bool:
        return self.access_token_expires_at <= now + leeway

    def is_refresh_token_expired(self, now: datetime) -> bool:
        return self.refresh_token_expires_at <= now
